# Br Invest
Projeto em HTML | CSS | JS para uma empresa fictícia de investimentos desenvolvido para avaliação (Faculdade) de Criação de Conteúdo Web, usando propriedades e técnicas que até então desconhecia.

package com.aula6;

public enum Tipo {
    Tecnológico, Escritório, Alimento;
}

